// Shared by the browser and Worker. Originals must never be persisted or returned.
(() => {
const keys=['date','hospital','patient','mrn','age','gender','asa','history','specialty','procedure','surgeon','caseType','technique','airway','airwayManagement','block','drugs','lines','monitoring','destination','complications','role','remarks','revenue'];
const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
// Display-only casing: never used by privacy sanitisation or cloud persistence.
// Preserve punctuation, initials, spacing, and already mixed-case spelling.
function formatSurgeon(value){return String(value??'').replace(/\p{L}[\p{L}\p{M}]*/gu,word=>word===word.toUpperCase()&&Array.from(word).length>1?Array.from(word)[0].toUpperCase()+Array.from(word).slice(1).join('').toLowerCase():word)}
function maskName(value){const letters=Array.from(String(value??'').normalize('NFC').trim()).filter(c=>/\p{L}/u.test(c));return letters.length?letters.slice(0,2).join('')+'•••':''}
function sanitize(records){
 if(!Array.isArray(records)||!records.length||records.length>30000)throw Error('Upload between 1 and 30,000 dated cases.');
 return records.map((source,i)=>{
  if(!source||typeof source!=='object')throw Error('Invalid case at row '+(i+1));
  const r={};for(const key of keys){if(source[key]!=null&&!['string','number'].includes(typeof source[key]))throw Error('Invalid '+key+' at row '+(i+1));r[key]=key==='surgeon'?String(source[key]??''):String(source[key]??'').trim();if(r[key].length>4000)throw Error('A case field exceeds 4,000 characters at row '+(i+1));}
  if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(r.date)||!Number.isFinite(Date.parse(r.date+'Z'))||new Date(r.date+'Z').toISOString().slice(0,19)!==r.date||Number(r.date.slice(0,4))<1900||Number(r.date.slice(0,4))>2200)throw Error('Invalid case date at row '+(i+1));
  if(r.revenue!==''&&(!Number.isFinite(Number(r.revenue))||Number(r.revenue)<0))throw Error('Invalid revenue at row '+(i+1));
  const name=r.patient,mrn=r.mrn,secrets=[name,...name.split(/\s+/).filter(s=>Array.from(s).length>=3&&!s.includes('•')),mrn].filter(s=>s&&s.length>=1&&!s.includes('•')).sort((a,b)=>b.length-a.length);
  // The surgeon field identifies the clinician, even when a patient shares their name.
  for(const key of keys){if(['patient','mrn','date','revenue','surgeon'].includes(key))continue;for(const secret of secrets)r[key]=r[key].replace(new RegExp('(?<![\\p{L}\\p{N}])'+escape(secret)+'(?![\\p{L}\\p{N}])','giu'),'[redacted]');r[key]=r[key].replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,'[email removed]').replace(/(?:\+?\d[\d ()-]{8,}\d)/g,'[number removed]');}
  r.patient=maskName(name);delete r.mrn;r.id='case-'+(i+1);return r;
 });
}
globalThis.LogbookPrivacy={keys,maskName,sanitize,formatSurgeon};
})();
