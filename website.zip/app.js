const $=s=>document.querySelector(s),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MF=window.MultiFilters,filterFields=['hospital','technique','specialty','caseType','surgeon','asa','procedure'],size=15;
let dataset=null,records=[],page=0,view='overview',printAll=false,pendingImport=null,loading=false,saving=false,etag='',cloudEpoch=0,cloudState='Loading shared dataset…';
const fields=Object.entries(window.LogbookImport.fields).filter(([k])=>k!=='mrn').map(([k,n])=>[k,k==='patient'?'Patient (masked)':n[0].replace(/\b\w/g,c=>c.toUpperCase())]);
function displayRecords(rows){return rows.map(r=>({...r,surgeon:LogbookPrivacy.formatSurgeon(r.surgeon)}))}
function toast(s){$('#toast').textContent=s;$('#toast').style.display='block';setTimeout(()=>$('#toast').style.display='none',5000)}
function money(n){return '₹'+Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:0})}
function options(k){const occurrences=new Map();for(const r of records){const value=r[k]||'Unspecified';occurrences.set(value,(occurrences.get(value)||0)+1)}return [...occurrences.keys()].sort((a,b)=>occurrences.get(b)-occurrences.get(a)||a.localeCompare(b,undefined,{sensitivity:'base',numeric:true}))}
function fillFilters(){const names={hospital:['Hospital','hospitals'],technique:['Technique','techniques'],specialty:['Specialty','specialties'],caseType:['Case type','case types'],surgeon:['Surgeon','surgeons'],asa:['ASA','ASA grades'],procedure:['Procedure','procedures']};for(const k of filterFields){const [label,plural]=names[k];MF.configure(k,options(k),{label,plural,all:'All '+plural})}const current=new Date().getFullYear(),recordYears=records.map(r=>Number(r.date.slice(0,4))).filter(Number.isFinite),first=Math.min(current,...recordYears)-1,last=Math.max(current,...recordYears)+1,years=Array.from({length:last-first+1},(_,i)=>String(first+i)),months=years.flatMap(y=>Array.from({length:12},(_,i)=>y+'-'+String(i+1).padStart(2,'0')));MF.configure('month',months.reverse(),{label:'Reporting months',plural:'months',all:'All months',format:m=>new Date(m+'-01T12:00:00').toLocaleDateString('en-IN',{month:'long',year:'numeric'})});MF.configure('year',years.reverse(),{label:'Reporting years',plural:'years',all:'All years'})}
function reportInput(){const mode=$('#reportingMode').value,selected=mode==='month'?MF.values('month'):mode==='year'?MF.values('year'):[],multiple=(mode==='month'||mode==='year')&&selected.length!==1;const from=$('#from').value,to=$('#to').value;const rangeLabel=from&&to?`${from} to ${to}`:from?`From ${from}`:to?`Through ${to}`:'Choose start and end dates';return {mode:multiple&&!selected.length?'all':mode,month:MF.values('month').at(-1)||'',year:MF.values('year').at(-1)||'',multiplePeriods:multiple,periodLabel:mode==='range'?rangeLabel:mode==='all'?'All recorded periods':MF.describe(mode==='year'?'year':'month')}}
function matchesReportingPeriod(r){const mode=$('#reportingMode').value;if(mode==='all')return true;if(mode==='range'){const date=String(r.date||'').slice(0,10);if($('#from').value&&$('#to').value&&$('#from').value>$('#to').value)return false;return (!$('#from').value||date>=$('#from').value)&&(!$('#to').value||date<=$('#to').value)}return MF.matches(mode==='year'?'year':'month',r.date.slice(0,mode==='year'?4:7))}
function filtered(ignorePeriod=false){const [key,dir]=$('#caseSort').value.split('_');const q=view==='register'?$('#search').value.toLowerCase():'';return records.filter(r=>(ignorePeriod||matchesReportingPeriod(r))&&(!$('#excludeMAC').checked||String(r.technique||'').trim().toLowerCase()!=='mac w/o sedation')&&(!q||[r.patient,r.procedure,r.surgeon,r.hospital,r.technique,r.specialty,r.asa,r.caseType].some(v=>String(v||'').toLowerCase().includes(q)))&&filterFields.every(k=>MF.matches(k,r[k]||'Unspecified'))).sort((a,b)=>{const av=a[key]??'',bv=b[key]??'';if(key==='revenue'){if(av===''||bv==='')return av===''?(bv===''?0:1):-1;return (Number(av)-Number(bv))*(dir==='desc'?-1:1)}return String(av).localeCompare(String(bv),undefined,{sensitivity:'base',numeric:true})*(dir==='desc'?-1:1)})}
function counts(a,k){return a.reduce((o,r)=>(o[r[k]||'Unspecified']=(o[r[k]||'Unspecified']||0)+1,o),Object.create(null))}
function updateFilterPanel(){
 const panel=$('#filterPanel');if(!panel)return;
 panel.hidden=view==='entry';
 const selections=filterFields.reduce((n,k)=>n+MF.values(k).length,0);
 const mode=$('#reportingMode').value;
 const periods=mode==='month'?MF.values('month').length:mode==='year'?MF.values('year').length:0;
 const extras=(mode==='range'?['#from','#to'].filter(k=>Boolean($(k).value)).length:0)+($('#excludeMAC').checked?1:0);
 const n=selections+periods+extras;
 const badge=$('#activeFilterCount');badge.hidden=n===0;badge.textContent=n+' active';
 $('#filterSummaryLabel').textContent=panel.open?'Hide filters':'Show filters';
 $('#filterHint').textContent=n?n+' active filter selection'+(n===1?'':'s')+' applied':'No filters selected. Showing the chosen reporting period.';
}
function render(){
 $('#search').hidden=view!=='register';const a=filtered();renderMonthly(a);$('#monthlyControls').hidden=view==='entry';
 $('#emptyDataset').hidden=Boolean(dataset);
 $('#syncFooterStatus').textContent=dataset?.lastSheetSync?('Last successful fetch: '+new Date(dataset.lastSheetSync).toLocaleString('en-IN',{dateStyle:'medium',timeStyle:'short'})+' · '+records.length+' cases · Google Sheets (log)'):'No successful Google Sheets fetch recorded yet.';
 $('#datasetStatus').textContent=(dataset?records.length+' shared cases · uploaded '+new Date(dataset.uploadedAt).toLocaleString('en-IN')+' · ':'')+cloudState+(dataset?.lastSheetSync?' · Last Google Sheets publish: '+new Date(dataset.lastSheetSync).toLocaleString('en-IN'):' · No Google Sheets publish recorded');
 $('.dataset-panel').hidden=view!=='entry';$('#syncFooter').hidden=view!=='entry';$('#stats').hidden=view!=='overview'||!dataset;$('.register').hidden=view!=='register'||!dataset;$('#monthlyDashboard').hidden=view!=='overview'||!dataset;$('#progression').hidden=view!=='progression'||!dataset;$('#caseEntry').hidden=view!=='entry';$('#fetchSheets').hidden=view==='overview'||view==='progression';$('.filters').hidden=view==='entry';$('#monthlyControls').hidden=view==='entry';$('#emptyDataset').hidden=Boolean(dataset)||view==='entry';
 if(view==='progression'&&dataset)window.Progression.render({reportRecords:records,all:filtered(true),selected:a,from:$('#from').value,to:$('#to').value,...reportInput()});
 const revenue=a.reduce((n,r)=>n+(Number(r.revenue)||0),0),em=a.filter(r=>/^emergency$/i.test(r.caseType)).length;
 $('#stats').innerHTML=[['Total cases',a.length,'Matching the selected filters'],['Emergency cases',em,(a.length?Math.round(em/a.length*100):0)+'% of selected cases'],['Hospitals',new Set(a.map(r=>r.hospital).filter(Boolean)).size,'Across your practice'],['Recorded revenue',money(revenue),a.filter(r=>r.revenue!=='').length+' cases with revenue entered']].filter(s=>!(s[0]==='Hospitals'&&s[1]===1)&&!(s[0]==='Recorded revenue'&&revenue===0)).map(s=>'<div class="stat"><label>'+s[0]+'</label><strong>'+s[1]+'</strong><small>'+s[2]+'</small></div>').join('');
 page=Math.min(page,Math.max(0,Math.ceil(a.length/size)-1));const shown=printAll?a:a.slice(page*size,(page+1)*size);
 $('#rows').innerHTML=shown.map(r=>'<tr><td>'+esc(new Date(r.date).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}))+'<small>'+esc(r.date.slice(11,16))+'</small></td><td><b>'+esc(r.patient||'Patient not recorded')+'</b><small>Name masked · MRN hidden</small></td><td><b>'+esc(r.procedure||'Procedure not recorded')+'</b><small>'+esc(r.hospital)+'</small></td><td><span class="badge">'+esc(r.technique||'—')+'</span></td><td>'+esc(r.asa||'—')+'</td><td><span class="badge '+(/^emergency$/i.test(r.caseType)?'emergency':'')+'">'+esc(r.caseType||'—')+'</span></td><td>'+(r.revenue!==''?money(r.revenue):'—')+'</td><td><button data-view-case="'+esc(r.id)+'">View details</button></td></tr>').join('')||'<tr><td colspan="8">No cases match these filters.</td></tr>';
 $('#caseCards').innerHTML=shown.map(r=>'<article class="case-card"><div><strong>'+esc(r.patient||'Patient not recorded')+'</strong><span>'+esc(r.date.slice(0,10))+' · '+esc(r.date.slice(11,16))+'</span></div><p>'+esc(r.procedure||'Procedure not recorded')+'</p><small>'+esc(r.hospital||'Hospital not recorded')+' · '+esc(r.technique||'Technique not recorded')+'</small><p>'+esc(r.asa||'ASA not recorded')+' · '+esc(r.caseType||'Case type not recorded')+' · '+(r.revenue!==''?money(r.revenue):'Revenue not recorded')+'</p><button data-view-case="'+esc(r.id)+'">View details</button></article>').join('')||'<p>No cases match these filters.</p>';$('#count').textContent=a.length+' matching cases';$('#pageInfo').textContent=a.length?(printAll?1:page*size+1)+'–'+(printAll?a.length:Math.min((page+1)*size,a.length))+' of '+a.length+' cases':'0 cases';$('#prev').disabled=page===0||printAll;$('#next').disabled=(page+1)*size>=a.length||printAll;updateFilterPanel();
}
function resetFilters(latest=false){for(const s of ['#search','#from','#to'])$(s).value='';$('#excludeMAC').checked=false;for(const k of [...filterFields,'month','year'])MF.set(k,[]);$('#reportingMode').value=latest?'month':'all';if(latest){const month=records.map(r=>r.date.slice(0,7)).sort().at(-1);if(month){MF.set('month',[month]);MF.set('year',[month.slice(0,4)])}}page=0}
function download(name,data,type){const url=URL.createObjectURL(new Blob([data],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
$('#upload').onclick=$('#emptyUpload').onclick=()=>$('#datasetFile').click();
let importing=false;
function importBusy(value,label){importing=value;for(const id of ['#upload','#emptyUpload','#fetchSheets'])$(id).disabled=value;$('#upload').textContent=value&&label==='file'?'Reading file…':'↑ Upload Excel / CSV';$('#fetchSheets').textContent=value&&label==='sheet'?'Fetching sheet…':'↻ Fetch from G Sheets'}
function showImportPreview(result){
result.records=window.LogbookPrivacy.sanitize(result.records);pendingImport=result;
 const key=r=>JSON.stringify(Object.entries(r).filter(([k])=>k!=='id').sort(([a],[b])=>a.localeCompare(b)));
 const seen=new Map();let duplicates=0;for(const r of result.records){const k=key(r);if(seen.has(k))duplicates++;else seen.set(k,1)}
 const old=new Map();for(const r of dataset?.records||[]){const k=key(r);old.set(k,(old.get(k)||0)+1)}let matched=0;for(const r of result.records){const k=key(r),n=old.get(k)||0;if(n){matched++;old.set(k,n-1)}}
 $('#importCompare').textContent=duplicates+' potential duplicate rows after masking (retained). '+(dataset?(result.records.length-matched)+' rows differ from the current dataset; '+matched+' unchanged. Matching uses masked fields, so changes cannot be reliably distinguished from new cases.':'No prior dataset for comparison.');
const dates=result.records.map(r=>r.date.slice(0,10)).sort();
 $('#importSummary').textContent=result.records.length+' cases · '+dates[0]+' to '+dates.at(-1)+' · '+result.format;
 $('#importWarnings').textContent=[result.invalid.length?'Skipped '+result.invalid.length+' rows with missing or invalid dates (rows '+result.invalid.join(', ')+').':'',result.warnings.length?'Revenue unrecorded in source rows '+result.warnings.join(', ')+'.':'',result.missing.length?'Columns not found: '+result.missing.join(', ')+'. Their report values will be unspecified.':'',result.blank?result.blank+' empty/helper rows ignored.':''].filter(Boolean).join(' ');
 $('#importPreview').innerHTML=result.records.slice(0,5).map(r=>'<tr><td>'+esc(r.date.replace('T',' '))+'</td><td>'+esc(r.hospital)+'</td><td>'+esc(r.patient||'Not recorded')+'</td><td>'+esc(r.procedure||'Not recorded')+'</td></tr>').join('');
 $('#importReplaceNote').textContent=(dataset?'This replaces the current '+records.length+' shared cases for everyone. Cases will not be merged.':'This becomes the shared cloud dataset for everyone with the link.')+' Only masked names are sent; MRNs and the original file are not uploaded. The last successful upload wins.';
 $('#privacyReview').checked=false;$('#importConfirm').disabled=true;$('#importConfirm').textContent='Publish these '+result.records.length+' cases';$('#importDialog').showModal();
}
$('#datasetFile').onchange=async e=>{
 const file=e.target.files[0];if(!file||importing||saving||pendingImport)return;$('#uploadError').textContent='';importBusy(true,'file');
 try{showImportPreview(await window.LogbookImport.read(file))}
 catch(error){$('#uploadError').textContent=(error.message||'Unable to read file.')+' Current shared data is unchanged.'}
 finally{e.target.value='';importBusy(false)}
};
$('#fetchSheets').onclick=async()=>{
 if(importing||saving||pendingImport)return;
 $('#uploadError').textContent='';importBusy(true,'sheet');
 try{
  const response=await fetch('/api/sheets/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',cache:'no-store',signal:AbortSignal.timeout(45000)});
  const result=await response.json();if(!response.ok)throw Error(result.error||'Unable to fetch Google Sheet.');
  if(!Array.isArray(result.records)||!result.records.length)throw Error('Google Sheet contains no valid cases; current dataset preserved.');
  if(result.invalid?.length)throw Error('Google Sheet has '+result.invalid.length+' invalid date rows; current dataset preserved. Correct the source and fetch again.');
  const clean=window.LogbookPrivacy.sanitize(result.records);
  const payload=JSON.stringify({records:clean,source:'sheet'});
  if(new TextEncoder().encode(payload).length>15000000)throw Error('Dataset exceeds the 15 MB cloud limit.');
  saving=true;cloudEpoch++;
  const savedResponse=await fetch('/api/dataset',{method:'PUT',headers:{'Content-Type':'application/json'},body:payload,cache:'no-store',signal:AbortSignal.timeout(30000)});
  const saved=await savedResponse.json();if(!savedResponse.ok)throw Error(saved.error||'Cloud publish failed.');
  dataset=saved.dataset;records=displayRecords(dataset.records);window.LogbookCaseEntry?.refreshSuggestions();etag='';cloudState='Google Sheets · synchronized';fillFilters();resetFilters(true);render();
  toast('Google Sheets updated: '+records.length+' cases · '+new Date(dataset.lastSheetSync).toLocaleString('en-IN'));
 }catch(error){$('#uploadError').textContent=(error.message||'Unable to sync Google Sheets.')+' Existing shared data is unchanged.';toast('Google Sheets fetch failed; previous data retained.');}
 finally{saving=false;importBusy(false);}
};
$('#privacyReview').onchange=()=>$('#importConfirm').disabled=!$('#privacyReview').checked||saving;
$('#importCancel').onclick=()=>{if(!saving){$('#importDialog').close();pendingImport=null}};$('#importDialog').addEventListener('cancel',e=>{if(saving)e.preventDefault();else pendingImport=null});
$('#importConfirm').onclick=async()=>{
 if(!pendingImport||saving||!$('#privacyReview').checked)return;saving=true;cloudEpoch++;$('#importConfirm').disabled=true;$('#importCancel').disabled=true;$('#importConfirm').textContent='Saving shared dataset…';
 try{const payload=JSON.stringify({records:pendingImport.records,source:pendingImport.format?.startsWith('Google Sheets')?'sheet':'file'});if(new TextEncoder().encode(payload).length>15000000)throw Error('Dataset exceeds the 15 MB cloud limit.');const response=await fetch('/api/dataset',{method:'PUT',headers:{'Content-Type':'application/json'},body:payload,cache:'no-store',signal:AbortSignal.timeout(30000)}),result=await response.json();if(!response.ok)throw Error(result.error||'Cloud upload failed.');dataset=result.dataset;records=displayRecords(dataset.records);window.LogbookCaseEntry?.refreshSuggestions();etag='';pendingImport=null;cloudState='Shared cloud · names masked';$('#importDialog').close();fillFilters();resetFilters(true);render();toast('Shared dataset replaced. Everyone with the link can view these masked cases.');}
 catch(error){$('#importWarnings').textContent=error.message+' Your current view is unchanged. Refresh to check cloud status before retrying.';}
 finally{saving=false;$('#importCancel').disabled=false;$('#importConfirm').disabled=!$('#privacyReview').checked;$('#importConfirm').textContent=pendingImport?'Publish these '+pendingImport.records.length+' cases':'Publish dataset';}
};
async function loadCloud(){
 if(loading||saving||pendingImport||importing)return;loading=true;const epoch=cloudEpoch;$('#clearDataset').disabled=true;
 try{const response=await fetch('/api/dataset',{cache:'no-store',signal:AbortSignal.timeout(20000),headers:etag?{'If-None-Match':etag}:{}});if(epoch!==cloudEpoch)return;if(response.status===304){cloudState='Shared cloud · up to date';$('#uploadError').textContent='';return}const result=await response.json();if(epoch!==cloudEpoch)return;if(!response.ok)throw Error(result.error||'Cannot load cloud data.');const changed=dataset?.id!==result.dataset?.id;etag=response.headers.get('ETag')||'';dataset=result.dataset;records=displayRecords(dataset?.records||[]);window.LogbookCaseEntry?.refreshSuggestions();cloudState=dataset?'Shared cloud · names masked':'No shared dataset yet. Upload to share cases.';$('#uploadError').textContent='';if(changed){fillFilters();resetFilters(Boolean(dataset));$('#detailDialog').close();}}
 catch(error){cloudState='Cloud unavailable — '+(dataset?'loaded data may be outdated; refresh to check for updates.':'could not load the shared dataset.');$('#uploadError').textContent=error.message;}
 finally{loading=false;$('#clearDataset').disabled=false;render();}
}
$('#clearDataset').onclick=()=>loadCloud();
for(const container of [$('#rows'),$('#caseCards')])container.onclick=e=>{const id=e.target.dataset.viewCase;if(!id)return;const r=records.find(r=>r.id===id);if(!r)return;$('#caseDetails').innerHTML=fields.map(([k,label])=>'<div><dt>'+esc(label)+'</dt><dd>'+esc(r[k]||'Not recorded')+'</dd></div>').join('');$('#detailDialog').showModal()};
$('#detailClose').onclick=()=>$('#detailDialog').close();
$('#caseSort').onchange=()=>{page=0;render()};
for(const s of ['#search','#from','#to'])$(s).addEventListener('input',()=>{page=0;render()});document.addEventListener('filterchange',()=>{page=0;render()});
$('#filterPanel').addEventListener('toggle',updateFilterPanel);$('#filterDone').onclick=()=>{$('#filterPanel').open=false;updateFilterPanel()};
$('#reset').onclick=()=>{resetFilters();render()};$('#prev').onclick=()=>{page--;render()};$('#next').onclick=()=>{page++;render()};
document.querySelectorAll('[data-view]').forEach(el=>el.onclick=()=>{view=el.dataset.view;$('#subtitle').textContent=view==='register'?'Browse, search and export recorded cases from the shared dataset.':'Explore your uploaded logbook by reporting period and case filters.';document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n===el));$('#crumb').textContent=el.textContent.slice(2);page=0;render()});
$('#csv').onclick=()=>{const quote=v=>'"'+String(v??'').replace(/^(?=[\s]*[=+@-])/, "'").replaceAll('"','""')+'"';download('anesthesia-cases.csv','\uFEFF'+[fields.map(f=>quote(f[1])).join(','),...filtered().map(r=>fields.map(f=>quote(r[f[0]])).join(','))].join('\r\n'),'text/csv;charset=utf-8')};
$('#print').onclick=()=>{printAll=true;render();window.print();printAll=false;render()};$('#excludeMAC').onchange=()=>{page=0;render()};$('#reportingMode').onchange=()=>{if($('#reportingMode').value!=='range'){$('#from').value='';$('#to').value=''}page=0;render()};
fillFilters();resetFilters();render();loadCloud();setInterval(()=>{if(!document.hidden)loadCloud()},30000);window.addEventListener('focus',()=>loadCloud());document.addEventListener('visibilitychange',()=>{if(!document.hidden)loadCloud()});window.addEventListener('beforeprint',()=>{printAll=true;render()});window.addEventListener('afterprint',()=>{printAll=false;render()});

function ageSexDistribution(rows){
 const bands=[
  {label:'Under 18',min:0,max:17},
  {label:'18–29',min:18,max:29},
  {label:'30–44',min:30,max:44},
  {label:'45–59',min:45,max:59},
  {label:'60–74',min:60,max:74},
  {label:'75+',min:75,max:120}
 ].map(b=>({...b,female:0,male:0,total:0}));
 let excluded=0;
 for(const row of rows){
  const ageMatch=String(row.age??'').trim().match(/^(\d{1,3})(?:\.\d+)?/);
  const age=ageMatch?Number(ageMatch[1]):NaN;
  const sex=String(row.gender??'').trim().toLowerCase();
  const sexKey=['f','female','woman','women'].includes(sex)?'female':['m','male','man','men'].includes(sex)?'male':'';
  const band=bands.find(b=>Number.isFinite(age)&&age>=b.min&&age<=b.max);
  if(!band||!sexKey){excluded++;continue}
  band[sexKey]++;band.total++;
 }
 const female=bands.reduce((n,b)=>n+b.female,0),male=bands.reduce((n,b)=>n+b.male,0),total=female+male;
 const table=`<div class="table-wrap age-sex-table"><table><thead><tr><th>Age group</th><th>Female</th><th>Male</th><th>Total</th></tr></thead><tbody>${bands.map(b=>`<tr><td><b>${b.label}</b></td><td>${b.female}</td><td>${b.male}</td><td><b>${b.total}</b></td></tr>`).join('')}</tbody><tfoot><tr class="total-row"><td>Total</td><td>${female}</td><td>${male}</td><td>${total}</td></tr></tfoot></table></div>`;
 const w=760,h=330,left=58,right=22,top=30,bottom=58,cw=w-left-right,ch=h-top-bottom,maxValue=Math.max(0,...bands.map(b=>b.total)),scaleMax=Math.max(4,Math.ceil(maxValue/4)*4),x=i=>left+(i+.5)*cw/bands.length,y=v=>top+ch-v/scaleMax*ch,bw=Math.min(58,cw/bands.length*.52),femaleColor='#B77C9D',maleColor='#668BC4';
 let svg=`<svg class="age-sex-svg" viewBox="0 0 ${w} ${h}" role="img" aria-label="Stacked bar chart showing Female and Male case counts across six age groups"><title>Female and Male counts by age group</title>`;
 for(let i=0;i<=4;i++){const v=scaleMax*i/4,yy=y(v);svg+=`<line x1="${left}" x2="${w-right}" y1="${yy}" y2="${yy}" stroke="#E8EAF8"/><text x="${left-12}" y="${yy+4}" text-anchor="end">${Math.round(v)}</text>`}
 bands.forEach((b,i)=>{
  const cx=x(i),fh=b.female/scaleMax*ch,mh=b.male/scaleMax*ch,base=top+ch;
  if(b.female)svg+=`<rect x="${cx-bw/2}" y="${base-fh}" width="${bw}" height="${fh}" rx="2" fill="${femaleColor}"><title>${b.label} · Female: ${b.female}</title></rect>`;
  if(b.male)svg+=`<rect x="${cx-bw/2}" y="${base-fh-mh}" width="${bw}" height="${mh}" rx="2" fill="${maleColor}"><title>${b.label} · Male: ${b.male}</title></rect>`;
  if(b.female&&fh>=19)svg+=`<text class="age-sex-value" x="${cx}" y="${base-fh/2+4}" text-anchor="middle">${b.female}</text>`;
  if(b.male&&mh>=19)svg+=`<text class="age-sex-value" x="${cx}" y="${base-fh-mh/2+4}" text-anchor="middle">${b.male}</text>`;
  if(b.total)svg+=`<text class="age-sex-total" x="${cx}" y="${Math.max(16,base-fh-mh-9)}" text-anchor="middle">${b.total}</text>`;
  svg+=`<text x="${cx}" y="${h-25}" text-anchor="middle">${b.label}</text>`;
 });
 svg+='</svg>';
 const note=excluded?`${total} of ${rows.length} selected cases included. ${excluded} case${excluded===1?'':'s'} excluded because age or sex was missing or unrecognised.`:rows.length?`All ${total} selected cases have a recognised age and sex.`:'No cases match the selected filters.';
 return `<article class="monthly-card full age-sex-card"><div class="section-head"><h2>Age &amp; sex distribution</h2><span>${rows.length} selected cases</span></div><h3 class="age-sex-subhead">Summary breakdown by sex &amp; age group</h3>${table}<div class="age-sex-chart-heading"><h3>Age and sex distribution</h3><div class="age-sex-legend"><span><i style="background:${femaleColor}"></i>Female</span><span><i style="background:${maleColor}"></i>Male</span></div></div><div class="age-sex-chart-scroll">${svg}</div><p class="chart-note">${note}</p></article>`;
}

function renderMonthly(a){
 const visible=view==='overview';$('#monthlyControls').hidden=false;$('#monthlyDashboard').hidden=!visible;
 const mode=$('#reportingMode').value;$('#monthControl').hidden=mode!=='month';$('#yearControl').hidden=mode!=='year';$('#dateRangeControl').hidden=mode!=='range';const from=$('#from').value,to=$('#to').value,invalid=mode==='range'&&from&&to&&from>to;$('#dateRangeMessage').textContent=invalid?'Start date must be on or before end date.':'';const label=mode==='range'?(from&&to?from+' to '+to:from?'From '+from:to?'Through '+to:'Choose dates'):mode==='all'?'All cases':MF.describe(mode==='year'?'year':'month');$('#periodLabel').textContent=label;$('#heading').textContent=view==='entry'?'Case Entry.':view==='register'?'Case register.':view==='progression'?'Progression.':mode==='year'?'Annual statistics.':mode==='all'?'Practice statistics.':mode==='range'?'Date-range statistics.':'Monthly statistics.';$('#tableTitle').textContent=label+' · case register';
 if(!visible)return;
 const colors=['#505DB5','#4386b5','#eab76b','#8E99D3','#8b91c8','#c98eaa','#7986C9','#a8b8cb'];
 function entries(key,limit){return Object.entries(counts(a,key)).sort((x,y)=>y[1]-x[1]||x[0].localeCompare(y[0])).slice(0,limit||Infinity)}
 function panel(title,key,donut=false,limit){const es=entries(key,limit),total=a.length;let end=0;const segments=es.map(([k,n],i)=>{let start=end;end+=n/Math.max(1,total)*100;return colors[i%colors.length]+' '+start+'% '+end+'%'});if(end<99.99)segments.push('#E8EAF8 '+end+'% 100%');return `<article class="monthly-card"><div class="section-head"><h2>${title}</h2><span>${total} cases</span></div><div class="${donut?'distribution':'bars-only'}">${donut?`<div class="donut" role="img" aria-label="${esc(title)}: ${es.map(([k,n])=>esc(k)+': '+n).join(', ')}" style="background:${total?'conic-gradient('+segments.join(',')+')':'#E8EAF8'}"><div><b>${total}</b><small>cases</small></div></div>`:''}<div class="distribution-list">${es.length?es.map(([k,n],i)=>`<div class="category"><div><span class="color-dot" style="background:${colors[i%colors.length]}"></span><span>${esc(k)}</span><b>${n}</b><small>${Math.round(n/Math.max(1,total)*100)}%</small></div><div class="category-track"><i style="width:${n/Math.max(1,total)*100}%;background:${colors[i%colors.length]}"></i></div></div>`).join(''):'<p>No cases in this period.</p>'}</div></div>${limit&&Object.keys(counts(a,key)).length>limit?'<p class="chart-note">Showing the top '+limit+' categories. Percentages use all selected cases.</p>':''}</article>`}
 const days=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],slots=['Morning','Afternoon','Evening','Night'];const matrix=days.map(()=>[0,0,0,0]);a.forEach(r=>{const dt=new Date(r.date),h=Number(r.date.slice(11,13));if(!isNaN(dt))matrix[(dt.getDay()+6)%7][h<6||h>=21?3:h<12?0:h<17?1:2]++});const sums=slots.map((_,j)=>matrix.reduce((v,row)=>v+row[j],0)),max=Math.max(1,...matrix.map(row=>row.reduce((x,y)=>x+y,0)));const slotColors=['#8ebc99','#e9a1a0','#f0ce71','#95b8eb'];
 const dayChart=`<article class="monthly-card full"><div class="section-head"><h2>Cases by day & time</h2><span>Local case date and time</span></div><div class="day-layout"><div>${matrix.map((row,i)=>`<div class="day-bar"><span>${days[i]}</span><div>${row.map((n,j)=>`<i title="${days[i]} · ${slots[j]}: ${n}" style="width:${n/max*100}%;background:${slotColors[j]}">${n||''}</i>`).join('')}</div><b>${row.reduce((x,y)=>x+y,0)}</b></div>`).join('')}<div class="time-legend">${slots.map((s,i)=>`<span><i style="background:${slotColors[i]}"></i>${s}</span>`).join('')}</div></div><div class="table-wrap day-table"><table><thead><tr><th>Day / time</th>${slots.map(s=>'<th>'+s+'</th>').join('')}<th>Total</th></tr></thead><tbody>${matrix.map((row,i)=>'<tr><td>'+days[i]+'</td>'+row.map(n=>'<td class="heat" style="background:rgba(80,93,181,'+(n?0.07+n/max*.35:0)+')">'+n+'</td>').join('')+'<td><b>'+row.reduce((x,y)=>x+y,0)+'</b></td></tr>').join('')}<tr class="total-row"><td>Total</td>${sums.map(n=>'<td>'+n+'</td>').join('')}<td>${a.length}</td></tr></tbody></table></div></div><p class="chart-note">Morning 06:00–11:59 · Afternoon 12:00–16:59 · Evening 17:00–20:59 · Night 21:00–05:59</p></article>`;
 const hospitals=entries('hospital'),revenue=a.reduce((n,r)=>n+(Number(r.revenue)||0),0);
 const revenueSummary=rows=>{const entered=rows.filter(r=>r.revenue!==''&&r.revenue!=null&&Number.isFinite(Number(r.revenue)));const sum=entered.reduce((total,r)=>total+Number(r.revenue),0);return {sum,count:entered.length,average:entered.length?money(sum/entered.length):'—'}};
 const overall=revenueSummary(a);
 const hospital=`<article class="monthly-card full"><div class="section-head"><h2>Cases by hospitals</h2><span class="revenue-chip">Recorded revenue ${money(revenue)}</span></div><div class="table-wrap"><table><thead><tr><th>Hospital</th><th>Cases</th><th>Share</th><th>Recorded revenue</th><th>Average revenue / case</th></tr></thead><tbody>${hospitals.map(([h,n])=>{const summary=revenueSummary(a.filter(r=>(r.hospital||'Unspecified')===h));return `<tr><td>${esc(h)}</td><td><b>${n}</b></td><td>${Math.round(n/Math.max(a.length,1)*100)}%</td><td>${money(summary.sum)}</td><td>${summary.average}<small>${summary.count} cases with revenue</small></td></tr>`}).join('')||'<tr><td colspan="5">No cases in this period.</td></tr>'}<tr class="total-row"><td>Total</td><td>${a.length}</td><td>${a.length?'100%':'0%'}</td><td>${money(revenue)}</td><td>${overall.average}<small>${overall.count} cases with revenue</small></td></tr></tbody></table></div><p class="chart-note">Average revenue per case = recorded revenue ÷ cases with revenue entered. Blank revenue is excluded; zero revenue is included. Totals use the same calculation across all selected cases.</p></article>`;

 $('#monthlyDashboard').innerHTML=panel('Cases by specialties','specialty',true)+panel('Cases by anesthesia types','technique',true)+panel('Cases by ASA physical status','asa')+panel('Emergency vs elective','caseType',true)+panel('Cases by surgeons','surgeon',false,6)+panel('Top 5 surgeries','procedure',false,5)+dayChart+hospital+ageSexDistribution(a);
}
